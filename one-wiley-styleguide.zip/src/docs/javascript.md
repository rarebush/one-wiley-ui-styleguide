This is a markdown document.

```javascript
var foo = 'bar'
```
