/**
 * Toolkit JavaScript
 */

'use strict';
